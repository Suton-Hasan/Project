<?php
       $Name = $POST['Name'];
       $Phone = $POST['Number '];
       $Gender = $POST['Gender'];
       $Password = $POST['Password'];
//  database connection

if (!empty($Name)||!empty($Number)||!empty($Gender)||!empty($Password)){
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "reg";

    $conn = new mysqli($host,$dbUsername,$dbPassword,$dbname);
    if(mysqli_connect_error()){
        die('Connect Error('.mysqli_connect_errno().')'.mysqli_connect_error());
    }else{
        $sql = "INSERT Into registration1(Name,Number,Gender,Password)values(?,?,?,?)";
    
        $stmt -> execute();
        $rnum = $stmt -> num_rows;

        if($rnum==0){
            $stmt->close();
            $stmt=$conn->prepare($INSERT);
            $stmt->bind_param("sssi", $Name,$Number,$Gender,$Password);
            $stmt->execute();
            echo "Registration Successfully";

        }else{
            echo "Error:".$sql."<br>".$conn->error;
        }
        $stmt->close();
        $conn->close();


    }
}else{
    echo "All field are required";
    die();
}
?>